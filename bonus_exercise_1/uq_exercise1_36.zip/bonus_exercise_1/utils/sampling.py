from typing import Callable

import chaospy as cp
import numpy as np
import numpy.typing as npt

Function = Callable[[npt.NDArray], npt.NDArray]


def compute_rmse(values: npt.NDArray) -> npt.NDArray:
    return np.std(values, ddof=1, axis=1) / np.sqrt(values.shape[1])


def monte_carlo(
    p: cp.Distribution,
    n_samples: int,
    f: Function,
    transform: Function | None = None,
    rule: str = "random",
    seed: float = 42,
) -> tuple[npt.NDArray, npt.NDArray]:
    #  ✓ TODO: implement the Monte Carlo method.
    # Return the mean approximation and the corresponding RMSE. Make sure
    # the function works for both 1-dimensional and n-dimensional
    # distributions (see include_axis_dim parameter of
    # cp.Distribution.sample).
    # ====================================================================
    samples = p.sample(n_samples, rule=rule, seed=seed, include_axis_dim=True)
    if transform is not None:
        samples = transform(samples)

    values = f(samples)
    mean = np.mean(values, axis=-1, dtype=float)
    rmse = compute_rmse(values)
    # ====================================================================
    return mean, rmse


def control_variates(
    p: cp.Distribution,
    n_samples: int,
    f: Function,
    phi: Function,
    control_mean: float,
    seed: float = 42,
) -> npt.NDArray:
    # TODO: implement the control variates method that returns the mean
    # approximation. Make sure the function works for both 1-dimensional
    # and n-dimensional distributions.
    # ====================================================================
    samples = p.sample(n_samples, seed=seed, include_axis_dim=True)
    values_f = f(samples)
    values_phi = phi(samples)
    mean_f = np.mean(values_f, axis=-1, keepdims=True)
    mean_phi = np.mean(values_phi, axis=-1, keepdims=True)

    cov = np.mean((values_f - mean_f) * (values_phi - mean_phi), axis=-1)
    alpha = cov / np.var(values_phi, axis=-1)

    mean = np.mean(values_f, axis=-1) + alpha * (control_mean - np.mean(values_phi, axis=-1))
    # ====================================================================
    return mean


def importance_sampling(
    p: cp.Distribution,
    q: cp.Distribution,
    n_samples: int,
    f: Function,
    seed: float = 42,
) -> npt.NDArray:
    # TODO: implement the importance sampling that returns the mean
    # approximation. Make sure the function works for both 1-dimensional
    # and n-dimensional distributions.
    # ====================================================================
    samples = q.sample(n_samples, seed=seed, include_axis_dim=True)
    values = f(samples)
    mean = np.mean(values * (p.pdf(samples) / q.pdf(samples)), axis=-1)
    # ====================================================================
    return mean
